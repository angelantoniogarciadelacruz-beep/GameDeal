import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'busqueda_widget.dart' show BusquedaWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BusquedaModel extends FlutterFlowModel<BusquedaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for busqueda_juego widget.
  FocusNode? busquedaJuegoFocusNode;
  TextEditingController? busquedaJuegoTextController;
  String? Function(BuildContext, String?)? busquedaJuegoTextControllerValidator;
  // Stores action output result for [Firestore Query - Query a collection] action in IconButton widget.
  WishlistRecord? juegoExistente;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    busquedaJuegoFocusNode?.dispose();
    busquedaJuegoTextController?.dispose();
  }
}
