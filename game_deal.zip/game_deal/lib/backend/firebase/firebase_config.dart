import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAbEfpCRXeYrNp-Arf1G5wqspGYD5gbA-8",
            authDomain: "gamedeals-e0931.firebaseapp.com",
            projectId: "gamedeals-e0931",
            storageBucket: "gamedeals-e0931.firebasestorage.app",
            messagingSenderId: "114754476297",
            appId: "1:114754476297:web:8c8b0a59d9951342bf9bd8",
            measurementId: "G-Q032VSDGZD"));
  } else {
    await Firebase.initializeApp();
  }
}
