import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class WishlistRecord extends FirestoreRecord {
  WishlistRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "user_id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "game_title" field.
  String? _gameTitle;
  String get gameTitle => _gameTitle ?? '';
  bool hasGameTitle() => _gameTitle != null;

  // "url_imagen" field.
  String? _urlImagen;
  String get urlImagen => _urlImagen ?? '';
  bool hasUrlImagen() => _urlImagen != null;

  // "fecha_registro" field.
  DateTime? _fechaRegistro;
  DateTime? get fechaRegistro => _fechaRegistro;
  bool hasFechaRegistro() => _fechaRegistro != null;

  // "precio_venta" field.
  String? _precioVenta;
  String get precioVenta => _precioVenta ?? '';
  bool hasPrecioVenta() => _precioVenta != null;

  void _initializeFields() {
    _userId = snapshotData['user_id'] as String?;
    _gameTitle = snapshotData['game_title'] as String?;
    _urlImagen = snapshotData['url_imagen'] as String?;
    _fechaRegistro = snapshotData['fecha_registro'] as DateTime?;
    _precioVenta = snapshotData['precio_venta'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Wishlist');

  static Stream<WishlistRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WishlistRecord.fromSnapshot(s));

  static Future<WishlistRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WishlistRecord.fromSnapshot(s));

  static WishlistRecord fromSnapshot(DocumentSnapshot snapshot) =>
      WishlistRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WishlistRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WishlistRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WishlistRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WishlistRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWishlistRecordData({
  String? userId,
  String? gameTitle,
  String? urlImagen,
  DateTime? fechaRegistro,
  String? precioVenta,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user_id': userId,
      'game_title': gameTitle,
      'url_imagen': urlImagen,
      'fecha_registro': fechaRegistro,
      'precio_venta': precioVenta,
    }.withoutNulls,
  );

  return firestoreData;
}

class WishlistRecordDocumentEquality implements Equality<WishlistRecord> {
  const WishlistRecordDocumentEquality();

  @override
  bool equals(WishlistRecord? e1, WishlistRecord? e2) {
    return e1?.userId == e2?.userId &&
        e1?.gameTitle == e2?.gameTitle &&
        e1?.urlImagen == e2?.urlImagen &&
        e1?.fechaRegistro == e2?.fechaRegistro &&
        e1?.precioVenta == e2?.precioVenta;
  }

  @override
  int hash(WishlistRecord? e) => const ListEquality().hash([
        e?.userId,
        e?.gameTitle,
        e?.urlImagen,
        e?.fechaRegistro,
        e?.precioVenta
      ]);

  @override
  bool isValidKey(Object? o) => o is WishlistRecord;
}
