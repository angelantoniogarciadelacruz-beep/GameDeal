// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/busqueda/busqueda_widget.dart' show BusquedaWidget;
export '/pages/configuracion/configuracion_widget.dart'
    show ConfiguracionWidget;
export '/pages/menu/menu_widget.dart' show MenuWidget;
export '/pages/deseados/deseados_widget.dart' show DeseadosWidget;
export '/registro/registro_widget.dart' show RegistroWidget;
