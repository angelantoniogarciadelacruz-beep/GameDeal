package com.mycompany.gamedeal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
